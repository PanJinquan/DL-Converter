# 说明
-  `model_0.45_4_320x256_16_sim.opt`  针对横屏的指尖检测，模型输入width=320,height=256
-  `model_0.45_4_256x320_16_sim.opt`  针对竖屏的指尖检测，模型输入width=256,height=320
